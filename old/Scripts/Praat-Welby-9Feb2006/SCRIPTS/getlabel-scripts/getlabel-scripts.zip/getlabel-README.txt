getlabel-README.txt
Pauline Welby, http://www.icp.inpg.fr/~welby/

Labelling from a menu of choices requires a set of files, for example:

1. Tones.man (adapted from Cert.man, written by Jackson Liscombe, http://www1.cs.columbia.edu/~jaxin/)
2. readin-files-getlabel.praat (written by Pauline Welby)
3. settier.psc  (written by John T�ndering, http://www.cphling.dk/pers/johtnd/)
4. getlabel.praat  (written by John T�ndering, http://www.cphling.dk/pers/johtnd/)

Thanks to Jennifer Venditti (http://www1.cs.columbia.edu/~jjv/) for
explaining the workings of these scripts.

Instructions:

- "Read from file..." the file Tones.man (a man(ual) page, an editable
text file). Place it out of the way in the corner of your screen.

- Praat | Open Praat script... readin-files-getlabel.praat

- In the script window, Run | Run | Okay (after checking paths, etc.)
 
- On the man page, click the tier number you want to label (this calls
the settier.psc script to write the tiernumber to a .txt file). In the
Editor window, choose an interval (or a point) in the textgrid. Then
on the man page, choose which label (in blue in the manpage) you want
to insert into that interval (or at that point). This calls the
getlabel.praat script, which first gets the tier number from the .txt
file, then gets the interval start and endpoints, etc. Once it's got
the info for the interval (or the point), you can insert the label,
etc.

- N.B.: You can also delete a label, play an interval, and advance
through the different intervals.

- Click on Continue to go on to the next file in the list. Once you
click Continue, changes to the last file will be saved.
