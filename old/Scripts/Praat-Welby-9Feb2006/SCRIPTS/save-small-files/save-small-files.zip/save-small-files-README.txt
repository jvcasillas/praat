save-small-files-README.praat

Extract and save portions of a long sound file. 

1. Open the long sound file (e.g., SET3/longfile.wav) using:

Read | Open long sound file

2. Create a TextGrid file with a single tier called "words"

Annotate | To TextGrid...

Tier names: words
Point tiers: <delete contents and leave blank>

3. Place boundaries and label intervals in tier. These labels will
become the names of the small sound files. Hint: you can click in the
waveform or spectrogram, then press "Enter" to place the boundary
(rather than clicking the little circle with the mouse).

4. Save the TextGrid file.

5. Open save-small-files.praat:

Praat | Open Praat script...

Change the various parameters (name of long sound file, left and right
buffers, prefix and suffix, etc.) if necessary. The "append time"
option adds the start time of the small sound file (with respect to
the long sound file) to the file name. This prevents overwrite in case
there is more than one of the same label (producing, for example,
lass-5.05.wav and lass-7.84.wav).

N.B.: The Long sound object and the TextGrid object do not need to be
in the objects window when the script is run, but they can be.

Run the script:

Run | Run

N.B.: The script will first ask you to confirm that you have created a
TextGrid file.