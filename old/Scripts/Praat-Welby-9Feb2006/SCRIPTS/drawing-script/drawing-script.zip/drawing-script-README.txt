The file 02mc11-fig2.wmf is an example of a figure with tone labels
superimposed on the F0 curve. It was created using
draw-waveform-sgram-f0.praat, with the section introduced by the
following uncommented:

## To print F0 labels that follow the f0 contour,
## create a second TextGrid file (named baseFile2) 
##  with only the F0 label tier
## and uncomment the following lines

To produce 02mc11-fig2.wmf, the script used the soundfile
02mc11-fig.wav and two TextGrid files:

02mc11-fig.TextGrid  (contains a single tier, with words)
02mc11-fig2.TextGrid (contains a single tier, with tone labels)