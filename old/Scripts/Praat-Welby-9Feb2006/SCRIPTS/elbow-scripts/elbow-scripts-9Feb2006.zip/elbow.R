#############################################################################
## ELBOW.R 
##
## Takes as input a two columned 
## array of time and F0 values and finds
## the inflection point (elbow).  
##
## Use get_pitch.praat and extractF0.praat to get .F0 files
##
## Creates individual text files with .lelbow extension
## with time value of elbow (in seconds)
##
## Use .elbow files as input to add-elbow.praat 
##
## Usage: R --vanilla < ~/TUTORIALS/R/elbow.R
##
##
## Written by Mary Beckman and Pauline Welby (welby@ling.ohio-state.edu) 
## May 21, 2002, June 30, 2002 
##############################################################################

## loop, for each file with extension .F0
## set working directory (MUST CHANGE)

setwd("/home/welby/TUTORIALS/R/LOMBARD")

for (i in list.files(pattern=".F0$")){
        
    outfile<-c(paste(i,".elbow",sep=""))  # make output file with
					   # .elbow extension

## read in table of times and F0 values

pitches _ read.table(i)

## set variable to number of rows (samples)

nsamp _ length(pitches[,1])

## initialize minerror to a really high number

minerror _ 999999999999

## loop that works from 4th row to 4th to last row (so that lines have
## at least four points

for (i in c(4:(nsamp-3)) ) {
## computes residual for two lines, 1st up to loop, 2nd after loop
 a _ residuals(lsfit(pitches[c(1:i),1],pitches[(1:i),2])) 
 b _ residuals(lsfit(pitches[(i:nsamp),1],pitches[(i:nsamp),2]))
## adds the squared error values for each line 
 buffer _ sum(a*a) + sum(b*b)

## compares it to min error

 if(minerror > buffer) {
    minerror _ buffer
    coef1 _ coefficients(lsfit(pitches[(1:i),1],pitches[(1:i),2]))
    coef2 _ coefficients(lsfit(pitches[(i:nsamp),1],pitches[(i:nsamp),2]))
 }
}

## Cedric's code for getting intersection of the two chosen line
##  segments

xintersect _  (coef2[1] - coef1[1]) / ( coef1[2] - coef2[2] )

## write filename and xintersect to a text file

write(t(xintersect), file=outfile,ncolumns=1,append=TRUE)

## plotting stuff

xlim _ c(pitches[1,1],pitches[nsamp,1])
ylim _ c(min(pitches[,2]),max(pitches[,2]))
plot(pitches[,1],pitches[,2],type="p",xlim=xlim,ylim=ylim)
abline(v=xintersect)
par(new=TRUE)
plot(c(0,xintersect),c(coef1[1],(coef1[1]+coef1[2]*xintersect)),
  type="l",xlim=xlim,ylim=ylim)
par(new=TRUE)
plot(c(xintersect,ylim[2]),c((coef2[1]+coef2[2]*xintersect),
+ (coef2[1]+coef2[2]*ylim[2])),type="l",xlim=xlim,ylim=ylim)

}