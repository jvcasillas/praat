elbow-scripts-README.txt

A set of scripts for locating elbows (turning points) in the
fundamental frequency curve and adding appropriate labels to Praat
TextGrid files. Written by Mary Beckman
(http://www.ling.ohio-state.edu/~mbeckman/), Pauline Welby
(http://www.icp.inpg.fr/~welby/), or both MB and PW.

Brief description of the scripts:

1. extractF0.praat -- creates Pitch objects for specified files,
   extracts time and f0 values from the .Pitch files; for each file,
   creates a text file (with extension .F0) with this information in two
   columns. It assumes labels "o" and "p" flanking the region of the elbow. 

2. elbow.R -- This is an R script.  If you don't already have R
   installed, you can download it from www.cran.r-project.org (it's
   freeware) and install it on your PC or Unix system. For each of the
   specified files, the script calculates the position of the elbow
   using the best-fit procedure described in Mariapaola D'Imperio and
   Pauline Welby's dissertations
   (http://www.ling.ohio-state.edu/publications/dissertations/).
   Creates a text file with extension .lelbow which contains the
   location of the elbow.

3. add-elbow.praat -- Takes the time information from the .lelbow
   files and inserts an elbow label at that time in the specified
   tier. 

All the scripts need to be modified slightly before use: to look for
the right patterns in file names, the right directories, the right
labels (currently L2, o, p)

Why use a (semi-)automatic procedure for labelling L tones:

In a recent paper, we explain why it is sometimes not possible to
label L tones by hand. A quasi-final version of that paper, Welby,
Pauline and H�l�ne Loevenbruck. (to appear). "Anchored down in
Anchorage: Syllable structure and segmental anchoring in French."
Italian Journal of Linguistics. Special issue on ssue on
Autosegmental-metrical approaches to intonation in Europe: tonal
targets and anchors, edited by Mariapaola D'Imperio, is available at:

http://www.icp.inpg.fr/~welby/PAPERS/welby-loevenbruck-ijl-draft-2005.pdf

Here's what we say (p. 21):

	As many researchers have noted, reliably hand-labelling the
	starting points of rises (L tones) is often problematic, since
	they do not always correspond to F0 minima (Pierrehumbert &
	Beckman 1988; Xu 1998; D'Imperio 2000; Frota 2002; Welby 2002,
	2003, submitted). Of his Mandarin data, Xu (1998: 196,197)
	writes: "As a first approximation, the onset of the rise may
	be defined as the F0 minimum right before the rise. However,
	in some cases. . . the portion of the contour before the
	apparent rise is virtually flat and sometimes even rises
	slightly. In such cases, the F0 minima seem to be too far away
	from where the real rise is. . . ."  We find the same
	situation for some of our French data with target accentual
	phrases with a LLH pattern. In these cases, objectively
	determining the position of L2 by hand would have been nearly
	impossible. Therefore, as in our earlier work, we used a
	line-fitting procedure to automatically calculate the position
	of L2.15 Due to space considerations, we do not detail the
	procedure here, but refer the reader to Welby (2003,
	submitted) for a detailed explanation of the procedure (see
	also D'Imperio, 2000). 

A set of example files is given in the SET4 folder. In the example,
the position of L2 is calculated by the series of scripts.

elbow-example.wav
elbow-example.F0
elbow-example.F0.elbow

The example is drawn from a pilot study on intonational adaptations in
Lombard speech (speech in noise) done in collaboration with Lucie
Bailly (ICP), Ma�va Garnier (Laboratoire d'Acoustique Musicale,
Paris), Marion Dohen (ICP), H�l�ne Loevenbruck (ICP).

