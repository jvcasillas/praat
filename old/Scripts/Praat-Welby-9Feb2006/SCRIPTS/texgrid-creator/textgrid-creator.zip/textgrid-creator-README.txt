textgrid-creator.praat

The script was written by Kyuchul Yoon and modified by Pauline
Welby. Given a plain text file containing sentences by the line, the
script tokenizes each sentence based on the word-boundary symbol (be
it a space or any other symbol), creates a default textgrid with one
interval tier (or modifies an existing textgrid), and inserts the
tokenized words into the interval tier.  It can 1. create new
TextGrid, 2. insert words into existing tier of existing TextGrid,
3. create new tier of existing TextGrid and insert words.

To use:

1. Create a list of sound files (e.g., LISTS/sounds.txt). Save the file.

2. Create a corresponding list of sentences (e.g.,
LISTS/sentences.txt). Save the file.

Be sure that the two lists use the same order.

3. Open textgrid-creator.praat:

Praat | Open Praat script...

4. Run the script:

Run | Run

5. Modify the boundaries. Click "continue" to save TextGrid and go on
to next file.
