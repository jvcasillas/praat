label-tones.praat

The current script works to label landmarks relevant to tonal
alignment of the nuclear accents in two varieties of Connaught Irish,
Cois Fharraige, Inis Oirr. The data are from a study by Martha Dalton
and Ailbhe N� Chasaide, Trinity College Dublin. For more
information, see the project page:
http://www.tcd.ie/CLCS/phonetics/projects/prosody.html.

The relevant soundfiles are in the folder SOUNDFILES\SET2.  The text
of the soundfiles, with English glosses is given below. The target
syllable is underlined.

N� maith le Daid� an _gob_.
'Daddy doesn't like the beak.'

N� maith le Daid� an _gob_�n
'Daddy doesn't like the tradesman.'

N� maith le Daid� an _gob_ad�n
'Daddy doesn't like the sandpiper.'

In the file names, Nuc0, Nuc1, Nuc2 refer to the number of syllables
following the target syllable.
